# Data Structures and Algorithms Coursework

*I confirm that the code contained in this file (other than that provided or authorised) is all my own work and has not been submitted elsewhere in fulfillment of this or any other award.*

## Your Details

### Name
Ivan Todorov
### Course
BSC Computing

**Date** : 27.04.2020